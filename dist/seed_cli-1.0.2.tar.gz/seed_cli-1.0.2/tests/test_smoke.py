def test_smoke_import():
    import seed_cli
    assert seed_cli.__version__
