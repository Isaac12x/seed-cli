
"""seed_cli.utils

Utility functions for common operations.

These utilities provide convenient ways to perform common tasks
that might be useful for users.
"""

from pathlib import Path
from typing import Optional


def extract_tree_from_image(
    image_path: Path,
    output_path: Optional[Path] = None,
    *,
    vars: Optional[dict] = None,
) -> Path:
    """Extract tree structure from an image and save to a .tree file.
    
    Uses OCR to extract text from an image, parses it as a tree structure,
    and saves the result to a .tree file.
    
    Args:
        image_path: Path to the image file (.png, .jpg, .jpeg)
        output_path: Optional output path. If not provided, uses image_path with .tree extension
        vars: Optional template variables to apply during parsing
    
    Returns:
        Path to the created .tree file
    
    Raises:
        RuntimeError: If image dependencies are not installed
        FileNotFoundError: If image_path doesn't exist
    """
    from ..image import extract_text_from_image, parse_image
    from ..capture import to_tree_text
    
    # Check if image exists
    if not image_path.exists():
        raise FileNotFoundError(f"Image file not found: {image_path}")
    
    # Determine output path
    if output_path is None:
        output_path = image_path.with_suffix(".tree")
    
    # Extract text from image using OCR
    text = extract_text_from_image(image_path)
    
    # Parse the image to get nodes
    _, nodes = parse_image(image_path, vars=vars)
    
    # Convert nodes to tree text format
    tree_text = to_tree_text(nodes)
    
    # Write to output file
    output_path.write_text(tree_text, encoding="utf-8")
    
    return output_path


def has_image_support() -> bool:
    """Check if image/OCR dependencies are installed.
    
    Returns:
        True if pytesseract and PIL are available, False otherwise
    """
    try:
        import pytesseract  # noqa
        from PIL import Image  # noqa
        return True
    except ImportError:
        return False
