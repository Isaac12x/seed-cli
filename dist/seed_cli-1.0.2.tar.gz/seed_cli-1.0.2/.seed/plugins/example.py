from seed_cli.plugins.base import SeedPlugin
class ExamplePlugin(SeedPlugin):
    name="example"
plugin = ExamplePlugin()
